#include "worksteal/policy.hpp"

namespace {
struct DisabledYield final : ws::Timing {
  explicit DisabledYield(const ws::Json &j) { ws::keys(j, {"name"}); }
  bool enabled() const override { return false; }
  ws::Idle idle(std::size_t) const override { return ws::Idle::yield; }
};
const bool registered = [] {
  ws::Registry<ws::Timing>::get().add("disabled_yield", [](const ws::Json &j) {
    return std::make_unique<DisabledYield>(j);
  });
  return true;
}();
} // namespace
