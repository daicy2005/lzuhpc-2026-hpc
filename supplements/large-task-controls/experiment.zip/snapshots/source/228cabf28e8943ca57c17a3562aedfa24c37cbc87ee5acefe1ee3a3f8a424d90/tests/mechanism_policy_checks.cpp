#include "worksteal/policy.hpp"
#include <iostream>

int main() {
  auto off = ws::Registry<ws::Timing>::get().make({{"name", "disabled_yield"}});
  auto on = ws::Registry<ws::Timing>::get().make({{"name", "immediate"}});
  if (off->enabled() || !on->enabled())
    return 1;
  for (std::size_t misses : {1U, 32U, 512U})
    if (off->idle(misses) != ws::Idle::yield || off->idle(misses) != on->idle(misses))
      return 2;
  try {
    ws::Registry<ws::Timing>::get().make({{"name", "disabled_yield"}, {"typo", 1}});
    return 3;
  } catch (const std::invalid_argument &) {}
  std::cout << "disabled_yield: disabled stealing, matching immediate idle; strict keys pass\n";
}
