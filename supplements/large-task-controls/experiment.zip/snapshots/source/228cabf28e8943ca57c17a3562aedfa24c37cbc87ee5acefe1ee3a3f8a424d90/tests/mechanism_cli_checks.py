import copy
import json
import pathlib
import subprocess
import sys
import tempfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'tools'))
import lab
import stealing_boundary_study as oracle

with tempfile.TemporaryDirectory(prefix='ws-mechanism-checks-') as directory:
    path = pathlib.Path(directory) / 'config.json'
    def run(config):
        path.write_text(json.dumps(config))
        p = subprocess.run([sys.argv[1], '--config', str(path)], capture_output=True,
                           text=True, timeout=20, check=True)
        r = json.loads(p.stdout)
        assert r['correctness']['pass']
        assert all(e['correctness']['exact_once'] for e in r['epochs'])
        return r

    for n in (0, 1, 17, 1031):
        c = lab.config('off', 4, 8, 7, n, 170011, 'compute_skewed', layout='concentrated')
        c['policies']['affinity'] = {'name': 'unbound'}
        c['policies']['steal_timing']['name'] = 'disabled_yield'
        c['measurement'].update(mode='diagnostic', epochs=3, pause_seed=73)
        r = run(c)
        assert all(sum(s['steals'] for s in e['worker_stats']) == 0 for e in r['epochs'])
        assert all(e['correctness']['output_hash_fnv1a64'] == oracle.small_output(c) for e in r['epochs'])

    c = lab.config('on', 4, 1, 1, 64, 170017, 'memory_reuse')
    c['policies']['affinity'] = {'name': 'unbound'}
    c['policies']['placement']['name'] = 'home'
    c['workload'].update(bytes_per_element=8192, passes=4)
    c['measurement'].update(mode='diagnostic', home_worker=0, epochs=3)
    dynamic = run(c)
    # A missing steal is a failed mechanism precondition, never a zero penalty.
    assert any(sum(s['steals'] for s in e['worker_stats']) > 0 for e in dynamic['epochs'])
    c['measurement']['controlled_worker'] = 1
    controlled = run(c)
    assert all(e['local_only'] and set(e['execution']['task_executor']) == {1}
               and sum(s['steals'] for s in e['worker_stats']) == 0 for e in controlled['epochs'])
    assert dynamic['epochs'][0]['pretouch_hash_fnv1a64'] == controlled['epochs'][0]['pretouch_hash_fnv1a64']
print('mechanism integration and independent output oracle: pass')
